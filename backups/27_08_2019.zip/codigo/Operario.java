public class Operario {
    private String imei;
    private String nombre;
    private String mailAdminContrata;


    public Operario(){

    }

    public Operario(String imei,String nombre){
        this.imei = imei;
        this.nombre = nombre;

    }
    
    public String getMailAdminContrata() {
        return mailAdminContrata;
    }

    public void setMailAdminContrata(String mailAdminContrata) {
        this.mailAdminContrata = mailAdminContrata;
    }
    
    //Resto de código (getters, setters, llamadas API, etc)
}
