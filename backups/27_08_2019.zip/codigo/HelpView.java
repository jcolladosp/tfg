public interface HelpView{

    void sendMailAdminContrata(Intent emailIntent);
    void showProgressBar();
    void hideProgressBar();

}