public class HelpActivity extends AppCompatActivity implements HelpView {

    private HelpActivityPresenter presenter;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
       

        presenter = new HelpActivityPresenter(this);

        initProgressBar();
        initActionBar();

    }


    @OnClick(R.id.adminContactButton)
    public void onClickSendMailAdmin(){
        presenter.sendMailToAdmin();

    }

    @Override
    public void sendMailAdminContrata(Intent emailIntent) {
        startActivity(emailIntent);
    }

    @Override
    public void showProgressBar() {
        progressBar.setVisibility(View.VISIBLE);
    }

    @Override
    public void hideProgressBar() {
        progressBar.setVisibility(View.INVISIBLE);
    }

    private void initActionBar(){
        //Inicializamos la ActionBar
    }

    private void initProgressBar() {
       //Inicializamos la ProgressBar
    }
}