public class HelpActivityPresenter {

    private Operario operario;
    private HelpView view;

    public HelpActivityPresenter(HelpView view) {
        this.operario = new Operario();
        this.view = view;
    }


    public void sendMailToAdmin(){
        view.showProgressBar();

        String email = operario.getMailAdminContrata();
        view.sendMailAdminContrata(createIntentSendEmail(email));
        
        view.hideProgressBar();
    }

    public static Intent createIntentSendEmail(String to) {

        Intent emailIntent = new Intent(Intent.ACTION_SEND);
        emailIntent.setData(Uri.parse("mailto:"));
        emailIntent.setType("text/plain");

        emailIntent.putExtra(Intent.EXTRA_EMAIL, new String[]{to});

        return emailIntent;
    }
}